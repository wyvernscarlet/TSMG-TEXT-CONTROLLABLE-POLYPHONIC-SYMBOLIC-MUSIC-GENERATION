from setuptools import find_packages, setup

setup(
    name="polyffusion",
    packages=find_packages(),
)
