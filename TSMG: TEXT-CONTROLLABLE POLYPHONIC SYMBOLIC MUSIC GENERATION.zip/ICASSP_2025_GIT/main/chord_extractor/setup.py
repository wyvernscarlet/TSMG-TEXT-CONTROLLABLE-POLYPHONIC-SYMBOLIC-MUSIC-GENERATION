from setuptools import find_packages, setup

setup(
    name="chord_extractor",
    packages=find_packages(),
)
