from mir.extractors.extractor_base import ExtractorBase

__all__ = ["ExtractorBase"]
