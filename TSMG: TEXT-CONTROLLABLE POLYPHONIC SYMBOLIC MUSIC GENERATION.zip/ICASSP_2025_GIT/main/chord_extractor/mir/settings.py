SONIC_VISUALIZER_PATH = "C:/Program Files (x86)/Sonic Visualiser/Sonic Visualiser.exe"
SONIC_ANNOTATOR_PATH = (
    "C:/Program Files (x86)/Sonic Visualiser/annotator/sonic-annotator.exe"
)
DEFAULT_DATA_STORAGE_PATH = "E:/dataset/"
