from datasets import load_dataset
from transformers import BertTokenizer, BertModel
import torch
import muspy
import clip
from openai import OpenAI

client = OpenAI(api_key='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')

tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertModel.from_pretrained('bert-base-uncased')

ds = load_dataset("amaai-lab/MidiCaps")
train_ds = ds['train']
captionset = train_ds['caption']
midiset = train_ds['location']


# test_caption = captionset[5]
# test_midi_path = midiset[5]
#
# test_midi = muspy.read_midi(test_midi_path)
#
#
# test_token = tokenizer(test_caption, return_tensors='pt')
#
# with torch.no_grad():
#     outputs = model(**test_token)

#bert


# embedding = outputs.last_hidden_state[:, 0, :].squeeze().numpy()
#
# device = "cuda" if torch.cuda.is_available() else "cpu"
# model_clip, preprocess = clip.load("ViT-B/32", device=device)
#
# clip_token = clip.tokenize([test_caption]).to(device)
#
# with torch.no_grad():
#     text_features = model_clip.encode_text(clip_token)
#
# text_features = text_features.cpu().numpy()

#clip


response = client.embeddings.create(model = "text-embedding-ada-002",
input = "Fuck")

embedding = response.data[0].embedding


#print("Text Embedding shape:", text_features.shape)
#print("Text Embedding:", text_features)
print(f"embedding is {len(embedding)}")
