import pickle
import random
from argparse import ArgumentParser
from datetime import datetime
from os.path import join
from pathlib import Path
from typing import Optional

from datasets import load_dataset
import os

import json
import numpy as np
import torch
import random

from Audio_generation import generate_mousai, generate_mustango

device = "cuda" if torch.cuda.is_available() else "cpu"

ds = load_dataset("amaai-lab/MidiCaps")
train_ds = ds['train']
captionset = train_ds['caption']
midiset = train_ds['location']
key_set = train_ds['key']
ts_set = train_ds['time_signature']
tempo_set = train_ds['tempo']

test_number = 5

def dummy_cond_input(length, params):
    h = params.img_h
    w = params.img_w
    prmat2c = torch.zeros([length, 2, h, w]).to(device)
    pnotree = torch.zeros([length, h, 20, 6]).to(device)
    if "chord" in params.cond_type:
        chord = torch.zeros([length, params.chd_n_step, params.chd_input_dim]).to(
            device
        )
    else:
        chord = None
    prmat = torch.zeros([length, h, w]).to(device)
    text = None
    return prmat2c, pnotree, prmat, text




def scale_to_index(scale):
    major_scales = {
        'C major': 0, 'C# major': 1, 'Db major':1, 'D major': 2, 'D# major': 3, 'Eb major': 3,
        'E major': 4, 'F major': 5, 'F# major': 6,'Gb major': 6, 'G major': 7,
        'G# major': 8, 'Ab major': 8, 'A major': 9, 'A# major': 10, 'Bb major': 10, 'B major': 11
    }

    minor_scales = {
        'C minor': 3, 'C# minor': 4,'Db minor': 4, 'D minor': 5, 'D# minor': 6, 'Eb minor': 6,
        'E minor': 7, 'F minor': 8, 'F# minor': 9, 'Gb minor': 9, 'G minor': 10,
        'G# minor': 11, 'Ab minor': 11, 'A minor': 0, 'A# minor': 1, 'Bb minor': 1, 'B minor': 2
    }

    if scale in major_scales:
        return major_scales[scale]
    elif scale in minor_scales:
        return minor_scales[scale]
    else:
        raise ValueError("未知的音阶名称: " + scale)

def generate_unique_random_numbers(start, end, count):
    if count > (end - start + 1):
        raise ValueError("指定的数量大于范围内的数字总数")
    return random.sample(range(start, end + 1), count)



if __name__ == "__main__":
    random_numbers = generate_unique_random_numbers(0, 160000, test_number)
    text_input = [captionset[i] for i in random_numbers]
    save_path = 'audio_mustango'
    index_path = os.path.join(save_path, "index.json")
    text_path = os.path.join(save_path, "caption.json")
    with open(index_path, 'w') as f:
        json.dump(random_numbers, f)
    with open(text_path, 'w') as f:
        json.dump(text_input, f)
    # for i, text in enumerate(text_input):
    #     generate_mousai(text, save_path, random_numbers[i])

    for i, text in enumerate(text_input):
        generate_mustango(text, save_path, random_numbers[i])