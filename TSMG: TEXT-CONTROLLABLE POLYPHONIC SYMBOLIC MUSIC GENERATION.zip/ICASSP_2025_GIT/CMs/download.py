from huggingface_hub import snapshot_download

name = "declare-lab/mustango"  # 替换为您要下载的仓库ID
cache_dir = "download_content"  # 替换为您希望保存下载内容的目录路径

path = snapshot_download(repo_id=name, cache_dir=cache_dir)
