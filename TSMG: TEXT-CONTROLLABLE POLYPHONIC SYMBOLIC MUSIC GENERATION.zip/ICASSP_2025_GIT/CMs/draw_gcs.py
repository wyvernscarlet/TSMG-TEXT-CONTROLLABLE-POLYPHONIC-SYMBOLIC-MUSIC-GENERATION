import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
# Data points
points = [(95.83, 85.22, 'TSMG(BERT)'), (96.21, 86.97,'TSMG(T5)'), (96.62, 89.56,'TSMG(ADA-002)')]
colors = ['red', 'green', 'blue']
x_std_dev = [0.32, 0.25, 0.23]
y_std_dev = [2.55, 1.89, 1.99]

# Vertical and horizontal lines
v_lines = [(96.42, 'lightblue', 'MMM', 0.31, '#B0E0E6'), (96.77, 'lightgreen', 'FIGARO', 0.29, '#E0F8E0'),
           (97.02, 'orange', 'MMT', 0.14, '#FFDAB9'), (96.55, 'lightpink', 'MMT-BERT', 0.33, '#FADADD')]
h_lines = [(74.31, 'brown', 'Mousai', 2.45, '#D2B48C'), (83.12, 'purple', 'Mustango', 1.29, '#D8A0D1')]

# Create the plot
plt.figure(figsize=(8, 6))
plt.grid(True, zorder=0)
# Plot the points with different colors and labels
for point, color, x_std, y_std in zip(points, colors, x_std_dev, y_std_dev):
    plt.scatter(point[0], point[1], color=color, s=100, label=point[2],zorder=5)
    plt.errorbar(point[0], point[1], xerr=x_std, yerr=y_std ,fmt='o', capsize=5, capthick=2, elinewidth=2, color=color,zorder=5)

# Add vertical dashed lines
for v, color, label, std , color2 in v_lines:
    plt.axvline(x=v, color=color, linestyle='--', label=label,zorder=4)
    #plt.text(v, plt.ylim()[0], f'{v}', color=color, ha='center', va='bottom')
    plt.fill_betweenx(y=[0, 100], x1=v - std, x2=v + std, color=color2, alpha=0.5,zorder=3)

# Add horizontal dashed lines with colors and labels
for h, color, label, std, color2 in h_lines:
    plt.axhline(y=h, color=color, linestyle='--', label=label,zorder=4)
    #plt.text(plt.xlim()[0], h, f'{h}', color=color, ha='left', va='center')
    plt.fill_between(x=[0, 100], y1=h - std, y2=h + std, color=color2, alpha=0.5,zorder=3)

# Labels and title
plt.xlabel('GCS',fontsize=17)
plt.ylabel('Caption Similarity',fontsize=17)
plt.xlim(70,100)
plt.ylim(30,100)
plt.annotate(
    '',
    xy=(90, 70),  # Arrow end point
    xytext=(80, 50),  # Arrow start point
    textcoords='data',  # Text coordinates
    arrowprops=dict(facecolor='lightblue', edgecolor='white', width=60, headwidth=120, headlength=50, zorder=2),  # Arrow properties
    fontsize=12,
    color='black',  # Text color
    ha='center',
    va='center',
    zorder=2
)
mid_x = (90 + 80) / 2
mid_y = (70 + 50) / 2
plt.text(mid_x, mid_y, 'BETTER', fontsize=14, ha='center', va='center', color='white' ,backgroundcolor='lightblue', zorder=3)


# Show legend
plt.legend()

# Save the plot to a specific path
plt.savefig('/home/kinnryuu/実験結果/ICASSP/GCS', dpi=300, bbox_inches='tight')

# Show the plot
plt.show()