CUDA_VISIBLE_DEVICES=3 python train_beats.py --lr 5e-6 --epochs 8
CUDA_VISIBLE_DEVICES=3 python train_beats.py --lr 1e-5 --epochs 8